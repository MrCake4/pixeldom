const canvas = document.getElementById('mapCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const playerNation = {
    x: 0,
    y:0,
    food: 0,
    provinces:[],
    color: "red",
};

const nation = {
    x: 0,
    y:0,
    food: 0,
    provinces:[],
    color: "white",
};

// Start the game loop as soon as the image has been loaded
function startGame() {
    gameLoop();
}

function gameLoop() {
    drawMap();
    drawUI();
    expandPlayer();
    expand();
    requestAnimationFrame(gameLoop);
}

// MAP GENERATION
let map = [];

 const img = new Image();
 img.src = "maps/europe.png";

 img.onload = function () {
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0, img.width, img.height);

    const imageData = ctx.getImageData(0, 0, img.width, img.height);
    const data = imageData.data;

    // Iterate over pixels
    for (let i = 0; i < data.length; i += 4) {
        const red = data[i];
        const green = data[i + 1];
        const blue = data[i + 2];

        // Convert Colors
        const isLand = red < 128 && green < 128 && blue < 128;
        map.push(isLand ? 1 : 0);
    }
    initPlayerNation();
    initNation("purple");
    initNation("yellow");
    initNation("orange");
    initNation("pink");
    initNation("brown");
    generateFood();
    startGame();
};

function drawMap() {
    const pixelSize = 1;
    for (let i = 0; i < map.length; i++) {
        const color = map[i] === 1 ? "green" : (map[i] === 2 ? playerNation.color : (map[i] === 3 ? nation.color : "blue"));
        ctx.fillStyle = color;
        const x = (i % img.width) * pixelSize;
        const y = Math.floor(i / img.width) * pixelSize;
        ctx.fillRect(x, y, pixelSize, pixelSize);
    }
}

function initPlayerNation() {
    do {
        playerNation.x = Math.floor(Math.random() * img.width);
        playerNation.y = Math.floor(Math.random() * img.height);
    } while (map[playerNation.y * img.width + playerNation.x] !== 1);

    map[playerNation.y * img.width + playerNation.x] = 2; // Use a different value to represent player nation (e.g., 2)
    playerNation.provinces.push({ x: playerNation.x, y: playerNation.y });
}

function initNation(color) {
    nation.color = color;
    do {
        nation.x = Math.floor(Math.random() * img.width);
        nation.y = Math.floor(Math.random() * img.height);
    } while (map[nation.y * img.width + nation.x] !== 1);

    map[nation.y * img.width + nation.x] = 3; // Use a different value to represent player nation (e.g., 2)
    nation.provinces.push({ x: nation.x, y: nation.y });
}


// Function to generate food points every second
function generateFood() {
    setInterval(() => {
        playerNation.food += 1;
        nation.food += 1;
    }, 1);
}

function expandPlayer() {
    // Create a copy of the provinces array to avoid modifying it while iterating
    const provincesCopy = [...playerNation.provinces];

    // Radius of expansion
    const expansionRadius = 1;

    // Iterate over all provinces belonging to the player's nation
    for (const province of provincesCopy) {
        for (let dx = -expansionRadius; dx <= expansionRadius; dx++) {
            for (let dy = -expansionRadius; dy <= expansionRadius; dy++) {
                const x = province.x + dx;
                const y = province.y + dy;

                // Check if the neighboring pixel is a green province
                const index = y * img.width + x;

                if (
                    // ...
                    map[index] === 1 &&
                    playerNation.food >= 1 &&
                    !playerNation.provinces.some(p => p.x === x && p.y === y)
                ) {
                    playerNation.food -= 1;
                    map[index] = 2; // Use the same consistent numerical value for player nation
                    playerNation.provinces.push({ x, y });
                    playerNation.food += 1;

                }
            }
        }
    }
}

function expand(){
    const provincesCopy = [...nation.provinces];

    // Radius of expansion
    const expansionRadius = 1;

    // Iterate over all provinces belonging to the player's nation
    for (const province of provincesCopy) {
        for (let dx = -expansionRadius; dx <= expansionRadius; dx++) {
            for (let dy = -expansionRadius; dy <= expansionRadius; dy++) {
                const x = province.x + dx;
                const y = province.y + dy;

                // Check if the neighboring pixel is a green province
                const index = y * img.width + x;

                if (
                    // ...
                    map[index] === 1 &&
                    nation.food >= 1 &&
                    !nation.provinces.some(p => p.x === x && p.y === y)
                ) {
                    nation.food -= 1;
                    map[index] = 3; // Use the same consistent numerical value for player nation
                    nation.provinces.push({ x, y });
                    nation.food += 1;

                }
            }
        }
    }
}

function drawUI() {
    ctx.fillStyle = "black";
    ctx.font = "20px Arial";
    ctx.fillText(`Food: ${playerNation.food}`, 10, 30);
}
